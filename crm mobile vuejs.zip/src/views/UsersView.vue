<template>
  <div class="page-content">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px">
      <div style="font-size: 12px; font-weight: 700; color: var(--muted)">Users</div>
      <router-link v-if="canManage" id="add-user-btn" to="/user-add" class="btn-primary-crm btn-sm" style="display: flex">
        <i class="fas fa-plus me-1"></i> Add User
      </router-link>
    </div>

    <div class="search-wrap">
      <i class="fas fa-search"></i>
      <input v-model="search" id="user-search" type="text" class="form-control" placeholder="Search users..." />
    </div>

    <div class="chip-scroll">
      <div 
        class="chip role-chip" 
        :class="{ active: filter === '' }" 
        @click="selectRole('')"
      >
        All
      </div>
      <div 
        v-for="r in ['Admin', 'Manager', 'Team Leader', 'Team Coordinator', 'Employee']" 
        :key="r"
        class="chip role-chip" 
        :class="{ active: filter === r }"
        @click="selectRole(r)"
      >
        {{ r === 'Team Coordinator' ? 'Coordinator' : r }}
      </div>
    </div>

    <div id="users-list">
      <div v-if="!filteredUsers.length" class="empty-state">
        <i class="fas fa-users"></i>
        <p>No users found</p>
      </div>
      <router-link 
        v-else
        v-for="u in filteredUsers" 
        :key="u.id" 
        :to="'/user-details?id=' + u.id" 
        class="user-item"
      >
        <div class="ui-av">{{ getInitials(u.name) }}</div>
        <div class="ui-info">
          <div class="ui-name">{{ u.name }}</div>
          <div class="ui-role">{{ u.email }}</div>
        </div>
        <div class="ui-right">
          <span :class="u.status === 'Active' ? 'badge-active' : 'badge-inactive'">{{ u.status }}</span>
        </div>
      </router-link>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Auth } from '../services/auth'
import { Data } from '../services/data'
import { UI } from '../services/ui'
import { initials } from '../utils/helpers'
import RoleBadge from '../components/RoleBadge.vue'

export default {
  components: { RoleBadge },
  setup() {
    const router = useRouter()
    const filter = ref('')
    const search = ref('')
    const currentUser = ref(null)

    onMounted(() => {
      const user = Auth.me()
      if (!user) {
        router.push('/login')
        return
      }
      currentUser.value = user
      UI.hideLoading()
    })

    const canManage = computed(() => {
      return currentUser.value && Auth.can('manage_users', currentUser.value.role)
    })

    const selectRole = (role) => {
      filter.value = role
    }

    const filteredUsers = computed(() => {
      if (!currentUser.value) return []
      let users = Data.getUsersForUser(currentUser.value)

      if (filter.value) {
        users = users.filter(u => u.role === filter.value)
      }

      if (search.value) {
        const q = search.value.toLowerCase()
        users = users.filter(u => (u.name + u.email + u.role).toLowerCase().includes(q))
      }

      return users
    })

    const getInitials = (name) => initials(name)

    return {
      filter,
      search,
      canManage,
      selectRole,
      filteredUsers,
      getInitials
    }
  }
}
</script>
