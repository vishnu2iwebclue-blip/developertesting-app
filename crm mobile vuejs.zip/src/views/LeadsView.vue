<template>
  <div class="page-content">
    <!-- Chip Scroll -->
    <div class="chip-scroll">
      <div
        class="chip"
        :class="{ active: statusFilter === '' }"
        @click="selectChip('')"
      >
        All
      </div>
      <div 
        v-for="c in ['Hot', 'Warm', 'Solo', 'Cold', 'New Lead', 'Contacted']" 
        :key="c"
        class="chip"
        :class="{ 
          'hot-chip': c === 'Hot', 
          'warm-chip': c === 'Warm', 
          active: statusFilter === c 
        }"
        @click="selectChip(c)"
      >
        {{ c }}
      </div>
    </div>

    <!-- Search -->
    <div class="search-wrap">
      <i class="fas fa-search"></i>
      <input
        v-model="search"
        id="lead-search"
        type="text"
        class="form-control"
        placeholder="Search leads..."
      />
    </div>

    <!-- Filter Toggle -->
    <div class="filter-toggle-row">
      <button class="btn-outline-crm" style="flex: 1" @click="toggleFilter">
        <i class="fas fa-filter"></i> Filters
        <span v-if="activeFilterCount" id="filter-count-badge" class="filter-count-badge" style="display: inline;">
          {{ activeFilterCount }}
        </span>
      </button>
    </div>

    <!-- Filter Panel -->
    <div id="filter-panel" class="filter-panel" :class="{ open: filterOpen }">
      <div class="filter-row-2">
        <div class="filter-row-1">
          <label class="filter-lbl">Status</label>
          <select v-model="filters.status" class="filter-control">
            <option value="">All</option>
            <option v-for="s in statuses" :key="s" :value="s">{{ s }}</option>
          </select>
        </div>
        <div class="filter-row-1">
          <label class="filter-lbl">Category</label>
          <select v-model="filters.leadCategory" class="filter-control">
            <option value="">All</option>
            <option v-for="c in categories" :key="c" :value="c">{{ c }}</option>
          </select>
        </div>
      </div>
      <div class="filter-row-2">
        <div class="filter-row-1">
          <label class="filter-lbl">Payment</label>
          <select v-model="filters.paymentStatus" class="filter-control">
            <option value="">All</option>
            <option v-for="p in payments" :key="p" :value="p">{{ p }}</option>
          </select>
        </div>
        <div class="filter-row-1">
          <label class="filter-lbl">Call Status</label>
          <select v-model="filters.callStatus" class="filter-control">
            <option value="">All</option>
            <option v-for="cs in callStatuses" :key="cs" :value="cs">{{ cs }}</option>
          </select>
        </div>
      </div>
      <div class="filter-row-1">
        <label class="filter-lbl">Product</label>
        <select v-model="filters.product" class="filter-control">
          <option value="">All</option>
          <option v-for="p in products" :key="p" :value="p">{{ p }}</option>
        </select>
      </div>
      <div class="filter-row-1">
        <label class="filter-lbl">Business Category</label>
        <select v-model="filters.businessCategory" class="filter-control">
          <option value="">All</option>
          <option v-for="b in businessCats" :key="b" :value="b">{{ b }}</option>
        </select>
      </div>
      <div class="filter-row-2">
        <div class="filter-row-1">
          <label class="filter-lbl">Group</label>
          <select v-model="filters.groupId" class="filter-control">
            <option value="">All</option>
            <option v-for="g in groups" :key="g.id" :value="g.id">{{ g.name }}</option>
          </select>
        </div>
        <div class="filter-row-1">
          <label class="filter-lbl">Team</label>
          <select v-model="filters.teamId" class="filter-control">
            <option value="">All</option>
            <option v-for="t in teams" :key="t.id" :value="t.id">{{ t.name }}</option>
          </select>
        </div>
      </div>
      <div class="filter-row-1">
        <label class="filter-lbl">Assigned To</label>
        <select v-model="filters.assignedTo" class="filter-control">
          <option value="">All</option>
          <option v-for="u in emps" :key="u.id" :value="u.id">{{ u.name }}</option>
        </select>
      </div>
      <div class="filter-row-2">
        <div class="filter-row-1">
          <label class="filter-lbl">State</label>
          <input v-model="filters.state" type="text" class="filter-control" placeholder="State" />
        </div>
        <div class="filter-row-1">
          <label class="filter-lbl">Rating %</label>
          <select v-model="filters.rating" class="filter-control">
            <option value="">All</option>
            <option value="0">0-10%</option>
            <option value="10">10-20%</option>
            <option value="20">20-30%</option>
            <option value="30">30-40%</option>
            <option value="40">40-50%</option>
            <option value="50">50-60%</option>
            <option value="60">60-70%</option>
            <option value="70">70-80%</option>
            <option value="80">80-90%</option>
            <option value="90">90-100%</option>
          </select>
        </div>
      </div>
      <div class="filter-actions">
        <button class="btn-outline-crm" style="flex: 1" @click="applyFilters">Apply Filters</button>
        <button class="btn-outline-crm" style="flex: 1" @click="clearFilters">Clear All</button>
      </div>
    </div>

    <!-- Leads Count and Add Button -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px">
      <div id="leads-count" style="font-size: 12px; font-weight: 700; color: var(--muted)">
        {{ sortedLeads.length }} leads
      </div>
      <router-link to="/lead-add" class="btn-primary-crm btn-sm">
        <i class="fas fa-plus me-1"></i> Add Lead
      </router-link>
    </div>

    <!-- Leads List -->
    <div id="leads-list">
      <div v-if="!sortedLeads.length" class="empty-state">
        <i class="fas fa-users"></i>
        <p>No leads found</p>
      </div>
      <div v-else v-for="l in sortedLeads" :key="l.id" class="lead-item">
        <div class="li-top">
          <div class="li-av">{{ getInitials(l.clientName) }}</div>
          <div class="li-info">
            <div class="li-name">{{ l.clientName }}</div>
            <div class="li-sub">{{ l.clientCompany }} &bull; {{ l.city || l.state || '—' }}</div>
          </div>
          <div class="li-right">
            <span class="li-date">{{ l.nextCallDate || '' }}</span>
          </div>
        </div>
        <div class="li-meta">
          <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center">
            <StatusBadge :status="l.status" />
            <CategoryBadge :category="l.leadCategory" />
            <PaymentBadge :status="l.paymentStatus" />
          </div>
          <div class="li-actions">
            <a :href="'tel:' + l.clientMobile" class="action-btn call" title="Call"><i class="fas fa-phone"></i></a>
            <a :href="'https://wa.me/91' + l.clientMobile" target="_blank" class="action-btn wa" title="WhatsApp"><i class="fab fa-whatsapp"></i></a>
            <a :href="l.clientEmail ? 'mailto:' + l.clientEmail : '#'" class="action-btn mail" title="Email"><i class="fas fa-envelope"></i></a>
            <router-link :to="'/lead-details?id=' + l.id" class="action-btn view" title="View"><i class="fas fa-eye"></i></router-link>
            <router-link :to="'/lead-edit?id=' + l.id" class="action-btn edit" title="Edit"><i class="fas fa-edit"></i></router-link>
          </div>
        </div>
        <div style="font-size:10px;color:var(--muted);margin-top:6px">
          {{ l.product ? l.product.substring(0, 30) : '' }} &bull; {{ getUserName(l.assignedTo) }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Auth } from '../services/auth'
import { Data } from '../services/data'
import { UI } from '../services/ui'
import { initials } from '../utils/helpers'
import StatusBadge from '../components/StatusBadge.vue'
import CategoryBadge from '../components/CategoryBadge.vue'
import PaymentBadge from '../components/PaymentBadge.vue'

export default {
  components: { StatusBadge, CategoryBadge, PaymentBadge },
  setup() {
    const router = useRouter()
    const search = ref('')
    const statusFilter = ref('')
    const filterOpen = ref(false)
    const activeFilterCount = ref(0)

    const filters = ref({
      status: '',
      leadCategory: '',
      paymentStatus: '',
      callStatus: '',
      product: '',
      businessCategory: '',
      groupId: '',
      teamId: '',
      assignedTo: '',
      state: '',
      rating: ''
    })

    const currentUser = ref(null)
    const groups = ref([])
    const teams = ref([])
    const emps = ref([])

    const statuses = ['New Lead', 'Contacted', 'Follow-up Scheduled', 'Demo Scheduled', 'Proposal Sent', 'Negotiation', 'Won', 'Close (Won)', 'Lost', 'On Hold']
    const categories = ['Hot', 'Warm', 'Solo', 'Cold']
    const payments = ['Pay Today', 'Pay Tomorrow', 'Pay This Week', 'Pay Next Week', 'Pay Ignoring', 'Pay Lost']
    const callStatuses = ['Called - Interested', 'Called - Callback', 'Called - Not Interested', 'Called - Not Reachable', 'Called - Busy', 'Not Called']
    const products = ['Digital Business Card (V-Card)', 'WhatsApp Store', 'Custom Website & App', 'CRM / ERP / CMS / eCommerce Software', 'Digital Marketing', 'Other Services']
    const businessCats = ['IT Services', 'Manufacturing', 'Healthcare', 'Real Estate', 'Retail', 'Education', 'Logistics', 'Consulting', 'Hospitality']

    onMounted(() => {
      const user = Auth.me()
      if (!user) {
        router.push('/login')
        return
      }
      currentUser.value = user

      groups.value = Data.getAll('groups')
      teams.value = Data.getAll('teams')
      emps.value = Data.getEmployeesForUser(user)

      UI.hideLoading()
    })

    const selectChip = (val) => {
      statusFilter.value = val
    }

    const toggleFilter = () => {
      filterOpen.value = !filterOpen.value
    }

    const applyFilters = () => {
      const keys = Object.keys(filters.value)
      activeFilterCount.value = keys.filter(k => filters.value[k]).length
      filterOpen.value = false
    }

    const clearFilters = () => {
      Object.keys(filters.value).forEach(k => {
        filters.value[k] = ''
      })
      activeFilterCount.value = 0
      statusFilter.value = ''
      filterOpen.value = false
    }

    const sortedLeads = computed(() => {
      if (!currentUser.value) return []
      let leads = Data.getLeadsForUser(currentUser.value)

      if (statusFilter.value) {
        leads = leads.filter(l => l.status === statusFilter.value || l.leadCategory === statusFilter.value)
      }

      if (search.value) {
        const q = search.value.toLowerCase()
        leads = leads.filter(l => (l.clientName + l.clientCompany + l.clientMobile + (l.city || '') + (l.state || '')).toLowerCase().includes(q))
      }

      if (filters.value.status) leads = leads.filter(l => l.status === filters.value.status)
      if (filters.value.leadCategory) leads = leads.filter(l => l.leadCategory === filters.value.leadCategory)
      if (filters.value.paymentStatus) leads = leads.filter(l => l.paymentStatus === filters.value.paymentStatus)
      if (filters.value.callStatus) leads = leads.filter(l => l.callStatus === filters.value.callStatus)
      if (filters.value.product) leads = leads.filter(l => l.product === filters.value.product)
      if (filters.value.businessCategory) leads = leads.filter(l => l.businessCategory === filters.value.businessCategory)
      if (filters.value.groupId) leads = leads.filter(l => l.groupId === filters.value.groupId)
      if (filters.value.teamId) leads = leads.filter(l => l.teamId === filters.value.teamId)
      if (filters.value.assignedTo) leads = leads.filter(l => l.assignedTo === filters.value.assignedTo)
      if (filters.value.state) leads = leads.filter(l => (l.state || '').toLowerCase().includes(filters.value.state.toLowerCase()))
      if (filters.value.rating) {
        const r = parseInt(filters.value.rating)
        leads = leads.filter(l => parseInt(l.rating || 0) >= r && parseInt(l.rating || 0) < r + 10)
      }

      return [...leads].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    })

    const getInitials = (name) => initials(name)
    const getUserName = (id) => Data.getUserName(id)

    return {
      search,
      statusFilter,
      filterOpen,
      activeFilterCount,
      filters,
      statuses,
      categories,
      payments,
      callStatuses,
      products,
      businessCats,
      groups,
      teams,
      emps,
      selectChip,
      toggleFilter,
      applyFilters,
      clearFilters,
      sortedLeads,
      getInitials,
      getUserName
    }
  }
}
</script>
