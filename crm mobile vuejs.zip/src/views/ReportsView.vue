<template>
  <div class="page-content">
    <div class="mob-card">
      <div class="form-group">
        <label class="form-label">Date Range</label>
        <select v-model="range" class="form-select">
          <option value="all">All Time</option>
          <option value="month">This Month</option>
          <option value="quarter">This Quarter</option>
        </select>
      </div>
    </div>

    <div id="report-body">
      <div v-if="!hasAccess" class="empty-state">
        <i class="fas fa-lock"></i>
        <p>Reports available for Admin, Manager, Team Leader</p>
      </div>
      <div v-else>
        <!-- KPI Grid -->
        <div class="kpi-grid">
          <div class="kpi-card">
            <div class="kpi-icon-wrap" style="background:rgba(21,101,192,.1);color:var(--primary)"><i class="fas fa-users"></i></div>
            <div class="kpi-val">{{ stats.total }}</div>
            <div class="kpi-lbl">Total Leads</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-icon-wrap" style="background:rgba(46,125,50,.1);color:var(--success)"><i class="fas fa-trophy"></i></div>
            <div class="kpi-val">{{ stats.won }}</div>
            <div class="kpi-lbl">Won <span class="kpi-trend trend-up">{{ stats.conv }}%</span></div>
          </div>
          <div class="kpi-card">
            <div class="kpi-icon-wrap" style="background:rgba(230,81,0,.1);color:#E65100"><i class="fas fa-fire"></i></div>
            <div class="kpi-val">{{ stats.hot }}</div>
            <div class="kpi-lbl">Hot Leads</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-icon-wrap" style="background:rgba(198,40,40,.1);color:var(--danger)"><i class="fas fa-times-circle"></i></div>
            <div class="kpi-val">{{ stats.lost }}</div>
            <div class="kpi-lbl">Lost</div>
          </div>
        </div>

        <!-- Product Breakdown -->
        <div class="mob-card">
          <div class="mob-card-title" style="margin-bottom:10px">
            <i class="fas fa-box me-1" style="color:var(--primary)"></i> Product Breakdown
          </div>
          <div class="bar-chart-wrap">
            <div v-for="(v, i) in stats.barData" :key="i" class="bc-col">
              <div class="bc-track">
                <div class="bc-fill" :style="{ height: Math.round((v / stats.maxBar) * 100) + '%' }"></div>
              </div>
              <div class="bc-lbl">{{ prodShort[i] }}</div>
            </div>
          </div>
        </div>

        <!-- Lead Category -->
        <div class="mob-card">
          <div class="mob-card-title" style="margin-bottom:10px">
            <i class="fas fa-fire me-1" style="color:#E65100"></i> Lead Category
          </div>
          <div v-for="cat in stats.catCounts" :key="cat.c" class="prog-row">
            <div class="prog-hd">
              <span class="prog-key">{{ cat.c }}</span>
              <span class="prog-val">{{ cat.n }} ({{ stats.total ? Math.round((cat.n / stats.total) * 100) : 0 }}%)</span>
            </div>
            <div class="prog-bar">
              <div class="prog-fill" :style="{ width: (stats.total ? Math.round((cat.n / stats.total) * 100) : 0) + '%', background: cat.col }"></div>
            </div>
          </div>
        </div>

        <!-- Payment Status -->
        <div class="mob-card">
          <div class="mob-card-title" style="margin-bottom:10px">
            <i class="fas fa-credit-card me-1" style="color:var(--primary)"></i> Payment Status
          </div>
          <div v-for="p in payStatuses" :key="p.name" style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--bg);font-size:12px">
            <span style="font-weight:600">{{ p.name }}</span>
            <strong>{{ p.count }}</strong>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Auth } from '../services/auth'
import { Data } from '../services/data'
import { UI } from '../services/ui'

export default {
  setup() {
    const router = useRouter()
    const range = ref('all')
    const hasAccess = ref(false)
    const currentUser = ref(null)

    const products = ['Digital Business Card (V-Card)', 'WhatsApp Store', 'Custom Website & App', 'CRM / ERP / CMS / eCommerce Software', 'Digital Marketing', 'Other Services']
    const prodShort = ['V-Card', 'WA Store', 'Web/App', 'CRM/ERP', 'Mktg', 'Others']
    const paymentNames = ['Pay Today', 'Pay Tomorrow', 'Pay This Week', 'Pay Next Week', 'Pay Ignoring', 'Pay Lost']

    onMounted(() => {
      const user = Auth.me()
      if (!user) {
        router.push('/login')
        return
      }
      currentUser.value = user

      if (Auth.can('view_reports', user.role)) {
        hasAccess.value = true
      }

      UI.hideLoading()
    })

    const stats = computed(() => {
      if (!currentUser.value || !hasAccess.value) {
        return { total: 0, won: 0, lost: 0, hot: 0, conv: 0, barData: [], maxBar: 1, catCounts: [] }
      }

      let leads = Data.getLeadsForUser(currentUser.value)
      const now = new Date()

      if (range.value === 'month') {
        leads = leads.filter(l => {
          const d = new Date(l.createdAt)
          return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
        })
      } else if (range.value === 'quarter') {
        const qs = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1)
        leads = leads.filter(l => new Date(l.createdAt) >= qs)
      }

      const total = leads.length
      const won = leads.filter(l => l.status === 'Won' || l.status === 'Close (Won)').length
      const lost = leads.filter(l => l.status === 'Lost').length
      const hot = leads.filter(l => l.leadCategory === 'Hot').length
      const conv = total ? Math.round((won / total) * 100) : 0

      const barData = products.map(p => leads.filter(l => l.product === p).length)
      const maxBar = Math.max(1, ...barData)

      const catCounts = [
        ['Hot', '#FF6D00'],
        ['Warm', '#E65100'],
        ['Solo', '#283593'],
        ['Cold', '#0277BD']
      ].map(([c, col]) => ({
        c,
        col,
        n: leads.filter(l => l.leadCategory === c).length
      }))

      return {
        total,
        won,
        lost,
        hot,
        conv,
        barData,
        maxBar,
        catCounts
      }
    })

    const payStatuses = computed(() => {
      if (!currentUser.value || !hasAccess.value) return []
      let leads = Data.getLeadsForUser(currentUser.value)
      const now = new Date()

      if (range.value === 'month') {
        leads = leads.filter(l => {
          const d = new Date(l.createdAt)
          return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
        })
      } else if (range.value === 'quarter') {
        const qs = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1)
        leads = leads.filter(l => new Date(l.createdAt) >= qs)
      }

      return paymentNames.map(name => ({
        name,
        count: leads.filter(l => l.paymentStatus === name).length
      }))
    })

    return {
      range,
      hasAccess,
      stats,
      prodShort,
      payStatuses
    }
  }
}
</script>
