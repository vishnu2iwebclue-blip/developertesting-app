<template>
  <div class="page-content" v-if="loaded">
    <form @submit="save" id="lead-edit-form" class="mob-card">
      <div class="form-section-hd">Lead Information</div>

      <div class="form-group">
        <label class="form-label">Client Name <span class="required-mark">*</span></label>
        <input v-model="form.clientName" type="text" name="clientName" class="form-control" placeholder="Full name" />
      </div>

      <div class="form-group">
        <label class="form-label">Company <span class="required-mark">*</span></label>
        <input v-model="form.clientCompany" type="text" name="clientCompany" class="form-control" placeholder="Company name" />
      </div>

      <div class="form-group">
        <label class="form-label">Mobile <span class="required-mark">*</span></label>
        <input v-model="form.clientMobile" type="tel" name="clientMobile" class="form-control" placeholder="10-digit number" />
      </div>

      <div class="form-group">
        <label class="form-label">Email</label>
        <input v-model="form.clientEmail" type="email" name="clientEmail" class="form-control" placeholder="email@company.com" />
      </div>

      <div class="form-group">
        <label class="form-label">State</label>
        <input v-model="form.state" type="text" name="state" class="form-control" placeholder="State" />
      </div>

      <div class="form-group">
        <label class="form-label">City</label>
        <input v-model="form.city" type="text" name="city" class="form-control" placeholder="City" />
      </div>

      <div class="form-group">
        <label class="form-label">Product <span class="required-mark">*</span></label>
        <select v-model="form.product" name="product" class="form-select">
          <option value="">Select Product</option>
          <option value="Digital Business Card (V-Card)">Digital Business Card (V-Card)</option>
          <option value="WhatsApp Store">WhatsApp Store</option>
          <option value="Custom Website & App">Custom Website & App</option>
          <option value="CRM / ERP / CMS / eCommerce Software">CRM / ERP / CMS / eCommerce Software</option>
          <option value="Digital Marketing">Digital Marketing</option>
          <option value="Other Services">Other Services</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Regarding</label>
        <input v-model="form.regarding" type="text" name="regarding" class="form-control" placeholder="Regarding" />
      </div>

      <div class="form-section-hd">Call & Response</div>

      <div class="form-group">
        <label class="form-label">Call Status</label>
        <select v-model="form.callStatus" name="callStatus" class="form-select">
          <option value="">Select</option>
          <option value="Called - Interested">Called - Interested</option>
          <option value="Called - Callback">Called - Callback</option>
          <option value="Called - Not Interested">Called - Not Interested</option>
          <option value="Called - Not Reachable">Called - Not Reachable</option>
          <option value="Called - Busy">Called - Busy</option>
          <option value="Not Called">Not Called</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Client Response</label>
        <input v-model="form.clientResponse" type="text" name="clientResponse" class="form-control" placeholder="Response" />
      </div>

      <div class="form-group">
        <label class="form-label">Status</label>
        <select v-model="form.status" name="status" class="form-select">
          <option value="">Select</option>
          <option value="New Lead">New Lead</option>
          <option value="Contacted">Contacted</option>
          <option value="Follow-up Scheduled">Follow-up Scheduled</option>
          <option value="Demo Scheduled">Demo Scheduled</option>
          <option value="Proposal Sent">Proposal Sent</option>
          <option value="Negotiation">Negotiation</option>
          <option value="Won">Won</option>
          <option value="Close (Won)">Close (Won)</option>
          <option value="Lost">Lost</option>
          <option value="On Hold">On Hold</option>
          <option value="Hot">Hot</option>
          <option value="Warm">Warm</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Lead Category</label>
        <select v-model="form.leadCategory" name="leadCategory" class="form-select">
          <option value="">Select</option>
          <option value="Hot">Hot</option>
          <option value="Warm">Warm</option>
          <option value="Solo">Solo</option>
          <option value="Cold">Cold</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Rating (%)</label>
        <input v-model="form.rating" type="number" name="rating" class="form-control" placeholder="0-100" min="0" max="100" />
      </div>

      <div class="form-group">
        <label class="form-label">Payment Status</label>
        <select v-model="form.paymentStatus" name="paymentStatus" class="form-select">
          <option value="">Select</option>
          <option value="Pay Today">Pay Today</option>
          <option value="Pay Tomorrow">Pay Tomorrow</option>
          <option value="Pay This Week">Pay This Week</option>
          <option value="Pay Next Week">Pay Next Week</option>
          <option value="Pay Ignoring">Pay Ignoring</option>
          <option value="Pay Lost">Pay Lost</option>
        </select>
      </div>

      <div class="form-section-hd">Next Call</div>

      <div class="form-group">
        <label class="form-label">Next Call Date</label>
        <input v-model="form.nextCallDate" type="date" name="nextCallDate" class="form-control" />
      </div>

      <div class="form-group">
        <label class="form-label">Next Call Time</label>
        <input v-model="form.nextCallTime" type="time" name="nextCallTime" class="form-control" />
      </div>

      <div class="form-section-hd">Meeting</div>

      <div class="form-group">
        <label class="form-label">Meeting Type</label>
        <select v-model="form.meetingType" name="meetingType" class="form-select">
          <option value="">Select</option>
          <option value="Followup">Followup</option>
          <option value="Meeting">Meeting</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Meeting Agenda Type</label>
        <input v-model="form.meetingAgendaType" type="text" name="meetingAgendaType" class="form-control" placeholder="Agenda" />
      </div>

      <div class="form-group">
        <label class="form-label">Meeting Date</label>
        <input v-model="form.meetingDate" type="date" name="meetingDate" class="form-control" />
      </div>

      <div class="form-group">
        <label class="form-label">Meeting Time</label>
        <input v-model="form.meetingTime" type="time" name="meetingTime" class="form-control" />
      </div>

      <div class="form-group">
        <label class="form-label">Meeting Initiated By</label>
        <select v-model="form.meetingInitiatedBy" name="meetingInitiatedBy" class="form-select">
          <option value="">Select User</option>
          <option v-for="u in employees" :key="u.id" :value="u.id">{{ u.name }}</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Assigned To</label>
        <select v-model="form.assignedTo" name="assignedTo" class="form-select">
          <option value="">Select Employee</option>
          <option v-for="u in employees" :key="u.id" :value="u.id">{{ u.name }} ({{ u.role }})</option>
        </select>
      </div>

      <div class="form-section-hd">Additional Info</div>

      <div class="form-group">
        <label class="form-label">Business Category</label>
        <input v-model="form.businessCategory" type="text" name="businessCategory" class="form-control" placeholder="Business category" />
      </div>

      <div class="form-group">
        <label class="form-label">Created By</label>
        <select v-model="form.createdBy" name="createdBy" class="form-select">
          <option value="">Select User</option>
          <option v-for="u in employees" :key="u.id" :value="u.id">{{ u.name }}</option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">Notes</label>
        <textarea v-model="form.notes" name="notes" class="form-control" placeholder="Notes" style="min-height: 80px"></textarea>
      </div>

      <button type="submit" class="btn-primary-crm w-full">
        <i class="fas fa-save me-1"></i> Update Lead
      </button>
    </form>
  </div>
</template>

<script>
import { ref, reactive, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { Auth } from '../services/auth'
import { Data } from '../services/data'
import { UI } from '../services/ui'
import { nowISO } from '../utils/helpers'

export default {
  setup() {
    const route = useRoute()
    const router = useRouter()
    const employees = ref([])
    const loaded = ref(false)

    const form = reactive({
      clientName: '',
      clientCompany: '',
      clientMobile: '',
      clientEmail: '',
      state: '',
      city: '',
      product: '',
      regarding: '',
      callStatus: '',
      clientResponse: '',
      status: '',
      leadCategory: '',
      rating: '',
      paymentStatus: '',
      nextCallDate: '',
      nextCallTime: '',
      meetingType: '',
      meetingAgendaType: '',
      meetingDate: '',
      meetingTime: '',
      meetingInitiatedBy: '',
      assignedTo: '',
      businessCategory: '',
      createdBy: '',
      notes: ''
    })

    let id = ''

    onMounted(() => {
      const user = Auth.me()
      if (!user) {
        router.push('/login')
        return
      }

      id = route.query.id
      if (!id) {
        router.push('/leads')
        return
      }

      const lead = Data.getById('leads', id)
      if (!lead) {
        UI.toast('Lead not found', 'error')
        router.push('/leads')
        return
      }

      employees.value = Data.getEmployeesForUser(user)

      // Pre-fill form
      Object.assign(form, lead)
      loaded.value = true

      UI.hideLoading()
    })

    const save = (e) => {
      e.preventDefault()
      if (!form.clientName || !form.clientCompany || !form.clientMobile || !form.product) {
        UI.toast('Fill required fields', 'error')
        return
      }

      const existing = Data.getById('leads', id)
      const tm = Data.getAll('users').find(u => u.id === form.assignedTo)?.teamId || existing.teamId

      Data.upsert('leads', {
        ...existing,
        ...form,
        id,
        teamId: tm,
        updatedAt: nowISO()
      })

      UI.toast('Lead updated!', 'success')
      setTimeout(() => router.push('/lead-details?id=' + id), 800)
    }

    return {
      form,
      employees,
      loaded,
      save
    }
  }
}
</script>
