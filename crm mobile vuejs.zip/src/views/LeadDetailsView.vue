<template>
  <div class="page-content" v-if="lead">
    <div class="mob-card">
      <div id="det-header">
        <div style="font-size:11px;opacity:.7;margin-bottom:4px">{{ lead.id }}</div>
        <div style="font-size:18px;font-weight:800;margin-bottom:2px">{{ lead.clientName }}</div>
        <div style="font-size:13px;opacity:.8;margin-bottom:8px">{{ lead.clientCompany }} &bull; {{ lead.city || '' }} {{ lead.state || '' }}</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">
          <StatusBadge :status="lead.status" />
          <CategoryBadge :category="lead.leadCategory" />
          <PaymentBadge :status="lead.paymentStatus" />
        </div>
        <div v-if="lead.rating" style="margin-bottom:10px">
          <RatingBar :rating="parseInt(lead.rating)" />
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <a :href="'tel:' + lead.clientMobile" class="btn-outline-crm btn-sm" style="background:rgba(255,255,255,.9);color:#2E7D32"><i class="fas fa-phone me-1"></i>Call</a>
          <a :href="'https://wa.me/91' + lead.clientMobile" target="_blank" class="btn-outline-crm btn-sm" style="background:rgba(255,255,255,.9);color:#25D366"><i class="fab fa-whatsapp me-1"></i>WhatsApp</a>
          <a v-if="lead.clientEmail" :href="'mailto:' + lead.clientEmail" class="btn-outline-crm btn-sm" style="background:rgba(255,255,255,.9)"><i class="fas fa-envelope me-1"></i>Email</a>
          <router-link :to="'/lead-edit?id=' + lead.id" class="btn-outline-crm btn-sm" style="background:rgba(255,255,255,.9)"><i class="fas fa-edit me-1"></i>Edit</router-link>
          <router-link :to="'/lead-comm?id=' + lead.id" class="btn-outline-crm btn-sm" style="background:rgba(255,255,255,.9)"><i class="fas fa-comment me-1"></i>Comm</router-link>
          <router-link v-if="canAssign" :to="'/lead-assign?id=' + lead.id" class="btn-outline-crm btn-sm" style="background:rgba(255,255,255,.9)"><i class="fas fa-user-check me-1"></i>Assign</router-link>
          <button v-if="canDelete" class="btn-danger-crm btn-sm" @click="handleDelete"><i class="fas fa-trash me-1"></i>Delete</button>
        </div>
      </div>
    </div>

    <div class="mob-card">
      <div class="mob-card-title">Details</div>
      <div id="det-info">
        <div class="info-row" v-for="[key, val] in detailsList" :key="key">
          <div class="ir-key">{{ key }}</div>
          <div class="ir-val" v-html="val"></div>
        </div>
      </div>
    </div>

    <div v-if="lead.notes" class="mob-card">
      <div class="ir-key" style="margin-bottom:6px">Notes</div>
      <div style="font-size:13px;line-height:1.5;color:var(--txt)">{{ lead.notes }}</div>
    </div>

    <div class="mob-card">
      <div class="mob-card-title">Communications</div>
      <div id="det-comms">
        <div v-if="!lead.communications || !lead.communications.length" style="font-size:12px;color:var(--muted);text-align:center;padding:14px">
          No communications logged yet.
        </div>
        <div v-else class="comm-wrap">
          <div v-for="(c, idx) in lead.communications" :key="idx" class="comm-item">
            <div class="comm-dot"><i class="fas" :class="getCommIcon(c.type)" style="font-size:8px"></i></div>
            <div>
              <div class="comm-type">{{ c.type }}</div>
              <div class="comm-date">{{ c.date }} &bull; {{ getUserName(c.user) }}</div>
              <div class="comm-note">{{ c.notes }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { Auth } from '../services/auth'
import { Data } from '../services/data'
import { UI } from '../services/ui'
import { fmtDate, statusIcon } from '../utils/helpers'
import StatusBadge from '../components/StatusBadge.vue'
import CategoryBadge from '../components/CategoryBadge.vue'
import PaymentBadge from '../components/PaymentBadge.vue'
import RatingBar from '../components/RatingBar.vue'

export default {
  components: { StatusBadge, CategoryBadge, PaymentBadge, RatingBar },
  setup() {
    const route = useRoute()
    const router = useRouter()
    const lead = ref(null)
    const currentUser = ref(null)

    onMounted(() => {
      const user = Auth.me()
      if (!user) {
        router.push('/login')
        return
      }
      currentUser.value = user

      const id = route.query.id
      if (!id) {
        UI.toast('Lead not found', 'error')
        router.push('/leads')
        return
      }

      const l = Data.getById('leads', id)
      if (!l) {
        UI.toast('Lead not found', 'error')
        router.push('/leads')
        return
      }

      lead.value = l
      UI.hideLoading()
    })

    const canAssign = computed(() => {
      return currentUser.value && Auth.can('assign_lead', currentUser.value.role)
    })

    const canDelete = computed(() => {
      return currentUser.value && Auth.can('delete_lead', currentUser.value.role)
    })

    const detailsList = computed(() => {
      if (!lead.value) return []
      return [
        ['Mobile', `<a href="tel:${lead.value.clientMobile}" style="color:var(--primary)">${lead.value.clientMobile}</a>`],
        ['Email', lead.value.clientEmail || '—'],
        ['Product', lead.value.product],
        ['Lead Status', lead.value.status || 'New Lead'],
        ['Category', lead.value.leadCategory || '—'],
        ['Rating', lead.value.rating ? lead.value.rating + '%' : '—'],
        ['Payment', lead.value.paymentStatus || '—'],
        ['Call Status', lead.value.callStatus || '—'],
        ['Response', lead.value.clientResponse || '—'],
        ['Next Call', (lead.value.nextCallDate || '—') + (lead.value.nextCallTime ? ' ' + lead.value.nextCallTime : '')],
        ['Meeting Type', lead.value.meetingType || '—'],
        ['Meeting Agenda', lead.value.meetingAgendaType || '—'],
        ['Meeting Date', (lead.value.meetingDate || '—') + (lead.value.meetingTime ? ' ' + lead.value.meetingTime : '')],
        ['Meeting Initiated', Data.getUserName(lead.value.meetingInitiatedBy)],
        ['Assigned To', Data.getUserName(lead.value.assignedTo)],
        ['Group', Data.getGroupName(lead.value.groupId)],
        ['Team', Data.getTeamName(lead.value.teamId)],
        ['Business Category', lead.value.businessCategory || '—'],
        ['Regarding', lead.value.regarding || '—'],
        ['State / City', (lead.value.state || '—') + ' / ' + (lead.value.city || '—')],
        ['Created By', Data.getUserName(lead.value.createdBy)],
        ['Created', fmtDate(lead.value.createdAt)],
        ['Updated', fmtDate(lead.value.updatedAt)]
      ]
    })

    const getCommIcon = (type) => statusIcon(type)
    const getUserName = (id) => Data.getUserName(id)

    const handleDelete = () => {
      if (!lead.value) return
      UI.confirm('Delete Lead', 'Are you sure? This cannot be undone.', () => {
        Data.remove('leads', lead.value.id)
        UI.toast('Lead deleted', 'success')
        setTimeout(() => router.push('/leads'), 800)
      })
    }

    return {
      lead,
      canAssign,
      canDelete,
      detailsList,
      getCommIcon,
      getUserName,
      handleDelete
    }
  }
}
</script>
