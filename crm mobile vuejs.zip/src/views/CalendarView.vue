<template>
  <div class="page-content">
    <div id="cal-widget" class="mob-card">
      <div class="cal-nav">
        <span>{{ monthName }}</span>
        <div>
          <button class="cal-nav-btn" @click="prevMonth"><i class="fas fa-chevron-left"></i></button>
          <button class="cal-nav-btn" @click="nextMonth"><i class="fas fa-chevron-right"></i></button>
        </div>
      </div>
      <div class="cal-grid">
        <div v-for="d in ['S', 'M', 'T', 'W', 'T', 'F', 'S']" :key="d" class="cal-day-lbl">{{ d }}</div>
      </div>
      <div class="cal-grid" style="gap:2px">
        <div v-for="n in firstDay" :key="'empty-' + n"></div>
        <div 
          v-for="day in daysInMonthList" 
          :key="day.dateString"
          class="cal-date"
          :class="{ today: day.isToday, selected: day.isSelected && !day.isToday }"
          @click="selectDate(day.dateString)"
        >
          {{ day.dayNum }}
          <div v-if="day.hasEvent" class="cal-dot"></div>
          <div v-else style="height:3px"></div>
        </div>
      </div>
    </div>
    <div class="mob-card">
      <div id="cal-day-title" style="font-size: 13px; font-weight: 700; color: var(--primary); margin-bottom: 10px">
        {{ selectedDayLabel }}
      </div>
      <div id="cal-events">
        <div v-if="!dayEvents.length" class="empty-state">
          <i class="fas fa-calendar"></i>
          <p>No events on this day</p>
        </div>
        <router-link 
          v-else
          v-for="l in dayEvents" 
          :key="l.id" 
          :to="'/lead-details?id=' + l.id" 
          class="fu-item"
        >
          <div class="fu-time">{{ l.nextCallTime || l.meetingTime || '—' }}</div>
          <div class="fu-info">
            <div class="fu-name">{{ l.clientName }}</div>
            <div class="fu-co">{{ l.meetingAgendaType || (l.product ? l.product.substring(0, 22) : '') }}</div>
          </div>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { Auth } from '../services/auth'
import { Data } from '../services/data'
import { UI } from '../services/ui'
import { today } from '../utils/helpers'

export default {
  setup() {
    const router = useRouter()
    const year = ref(new Date().getFullYear())
    const month = ref(new Date().getMonth())
    const selected = ref(today())
    const leads = ref([])

    onMounted(() => {
      const user = Auth.me()
      if (!user) {
        router.push('/login')
        return
      }

      leads.value = Data.getLeadsForUser(user)
      UI.hideLoading()
    })

    const monthName = computed(() => {
      return new Date(year.value, month.value, 1).toLocaleString('default', { month: 'long', year: 'numeric' })
    })

    const firstDay = computed(() => {
      return new Date(year.value, month.value, 1).getDay()
    })

    const daysInMonthList = computed(() => {
      const y = year.value
      const m = month.value
      const daysCount = new Date(y, m + 1, 0).getDate()

      const eventDates = new Set([
        ...leads.value.map(l => l.nextCallDate),
        ...leads.value.map(l => l.meetingDate)
      ].filter(Boolean))

      return Array.from({ length: daysCount }, (_, i) => {
        const d = i + 1
        const dateString = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`
        return {
          dayNum: d,
          dateString,
          isToday: dateString === today(),
          isSelected: dateString === selected.value,
          hasEvent: eventDates.has(dateString)
        }
      })
    })

    const selectedDayLabel = computed(() => {
      const d = new Date(selected.value + 'T00:00:00')
      return d.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })
    })

    const dayEvents = computed(() => {
      return leads.value
        .filter(l => l.nextCallDate === selected.value || l.meetingDate === selected.value)
        .sort((a, b) => (a.nextCallTime || '').localeCompare(b.nextCallTime || ''))
    })

    const selectDate = (d) => {
      selected.value = d
    }

    const prevMonth = () => {
      if (month.value === 0) {
        month.value = 11
        year.value--
      } else {
        month.value--
      }
    }

    const nextMonth = () => {
      if (month.value === 11) {
        month.value = 0
        year.value++
      } else {
        month.value++
      }
    }

    return {
      monthName,
      firstDay,
      daysInMonthList,
      selectedDayLabel,
      dayEvents,
      selectDate,
      prevMonth,
      nextMonth
    }
  }
}
</script>
