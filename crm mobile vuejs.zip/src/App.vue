<template>
  <div class="phone-wrap">
    <div class="phone-frame">
      <div class="phone-island"></div>
      
      <!-- Status Bar in Proper Vue -->
      <div class="phone-status">
        <span>9:41</span>
        <div class="pstat-r">
          <i class="fas fa-signal" style="font-size:11px;color:var(--txt)"></i>
          <i class="fas fa-wifi" style="font-size:11px;color:var(--txt)"></i>
          <i class="fas fa-battery-three-quarters" style="font-size:11px;color:var(--txt)"></i>
        </div>
      </div>
      
      <router-view v-if="$route.path === '/login'" :key="$route.path" />
      <template v-else>
        <!-- Header in Proper Vue -->
        <div v-if="currentUser" class="mob-header">
          <router-link v-if="showBack" :to="backHref" class="hback">
            <i class="fas fa-arrow-left" style="font-size:16px"></i>
          </router-link>
          <span class="htitle">{{ pageTitle }}</span>
          <div class="haction">
            <div v-if="!showBack" class="av" :title="currentUser.name">{{ userInitials }}</div>
            <button class="hbtn" @click="logout" title="Logout">
              <i class="fas fa-sign-out-alt"></i>
            </button>
          </div>
        </div>

        <div id="main-content">
          <router-view :key="$route.path" />
        </div>

        <!-- Bottom Nav in Proper Vue -->
        <div v-if="currentUser" class="bnav">
          <router-link
            v-for="tab in visibleTabs"
            :key="tab.id"
            :to="'/' + tab.id"
            class="btab"
            :class="{ active: activeTab === tab.id || activeTab.startsWith(tab.id) }"
          >
            <div class="btab-icon"><i class="fas" :class="tab.icon"></i></div>
            <span class="btab-lbl">{{ tab.label }}</span>
          </router-link>
        </div>
      </template>
      
      <div id="loading-overlay">
        <div class="spinner-ring"></div>
        <p>Loading...</p>
      </div>
      <div id="toast-container"></div>
    </div>
  </div>
</template>

<script>
import { ref, computed, watch, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { Auth } from './services/auth'

export default {
  setup() {
    const router = useRouter()
    const route = useRoute()
    const currentUser = ref(null)

    const updateCurrentUser = () => {
      currentUser.value = Auth.me()
    }

    onMounted(() => {
      updateCurrentUser()
    })

    watch(() => route.path, () => {
      updateCurrentUser()
    })

    const pageMap = {
      '/login': 'login',
      '/dashboard': 'dashboard',
      '/insight-list': 'dashboard',
      '/leads': 'leads',
      '/lead-details': 'lead-details',
      '/lead-add': 'lead-add',
      '/lead-edit': 'lead-edit',
      '/lead-assign': 'lead-assign',
      '/lead-comm': 'lead-comm',
      '/calendar': 'calendar',
      '/reports': 'reports',
      '/users': 'users',
      '/user-details': 'user-details',
      '/user-add': 'user-add',
      '/user-edit': 'user-edit'
    }

    const activeTab = computed(() => {
      return pageMap[route.path] || 'dashboard'
    })

    const pageTitle = computed(() => {
      const titles = {
        dashboard: 'Insights',
        leads: 'Leads',
        calendar: 'Calendar',
        reports: 'Reports',
        users: 'Users',
        'lead-details': 'Lead Details',
        'lead-add': 'Add Lead',
        'lead-edit': 'Edit Lead',
        'lead-assign': 'Assign Lead',
        'lead-comm': 'Log Communication',
        'user-add': 'Add User',
        'user-edit': 'Edit User',
        'user-details': 'User Details'
      }
      return titles[activeTab.value] || 'CRM Pro'
    })

    const showBack = computed(() => {
      return [
        'lead-details',
        'lead-add',
        'lead-edit',
        'lead-assign',
        'lead-comm',
        'user-add',
        'user-edit',
        'user-details'
      ].includes(activeTab.value)
    })

    const backHref = computed(() => {
      if (activeTab.value.startsWith('lead')) {
        return '/leads'
      } else if (activeTab.value.startsWith('user')) {
        return '/users'
      }
      return '/dashboard'
    })

    const userInitials = computed(() => {
      if (!currentUser.value) return ''
      return (currentUser.value.name || '')
        .split(' ')
        .map(n => n[0])
        .join('')
        .substring(0, 2)
        .toUpperCase()
    })

    const TABS = [
      { id: 'dashboard', icon: 'fa-chart-pie', label: 'Insights' },
      { id: 'leads', icon: 'fa-users', label: 'Leads' },
      { id: 'calendar', icon: 'fa-calendar-alt', label: 'Calendar' },
      { id: 'reports', icon: 'fa-chart-bar', label: 'Reports' },
      { id: 'users', icon: 'fa-user-cog', label: 'Users' }
    ]

    const visibleTabs = computed(() => {
      if (!currentUser.value) return []
      return TABS.filter(t => {
        if (t.id === 'reports') return Auth.can('view_reports', currentUser.value.role)
        if (t.id === 'users') return ['Admin', 'Manager', 'Team Leader'].includes(currentUser.value.role)
        return true
      })
    })

    const logout = () => {
      sessionStorage.removeItem('crm_session')
      currentUser.value = null
      router.push('/login')
    }

    return {
      currentUser,
      activeTab,
      pageTitle,
      showBack,
      backHref,
      userInitials,
      visibleTabs,
      logout
    }
  }
}
</script>

<style>
@import '/css/style.css';
</style>

