const RAW_USERS = [
  {id:"USR001",empId:"EMP001",name:"Rajesh Kumar",email:"admin@crm.com",password:"admin123",mobile:"9876543210",role:"Admin",groupId:null,teamId:null,status:"Active",joiningDate:"2023-01-01"},
  {id:"USR002",empId:"EMP002",name:"Priya Sharma",email:"priya.sharma@crm.com",password:"pass123",mobile:"9876543211",role:"Manager",groupId:"GRP001",teamId:null,status:"Active",joiningDate:"2023-02-01"},
  {id:"USR003",empId:"EMP003",name:"Amit Patel",email:"amit.patel@crm.com",password:"pass123",mobile:"9876543212",role:"Manager",groupId:"GRP002",teamId:null,status:"Active",joiningDate:"2023-02-05"},
  {id:"USR004",empId:"EMP004",name:"Sunita Verma",email:"sunita.verma@crm.com",password:"pass123",mobile:"9876543213",role:"Manager",groupId:"GRP003",teamId:null,status:"Active",joiningDate:"2023-02-10"},
  {id:"USR005",empId:"EMP005",name:"Vikram Singh",email:"vikram.singh@crm.com",password:"pass123",mobile:"9876543214",role:"Manager",groupId:"GRP004",teamId:null,status:"Active",joiningDate:"2023-02-15"},
  {id:"USR006",empId:"EMP006",name:"Kavitha Reddy",email:"kavitha.reddy@crm.com",password:"pass123",mobile:"9876543215",role:"Manager",groupId:"GRP005",teamId:null,status:"Active",joiningDate:"2023-03-01"},
  {id:"USR012",empId:"EMP012",name:"Rohit Desai",email:"rohit.desai@crm.com",password:"pass123",mobile:"9876543221",role:"Team Leader",groupId:"GRP001",teamId:"TM001",status:"Active",joiningDate:"2023-04-10"},
  {id:"USR013",empId:"EMP013",name:"Anita Kulkarni",email:"anita.kulkarni@crm.com",password:"pass123",mobile:"9876543222",role:"Team Coordinator",groupId:"GRP001",teamId:"TM001",status:"Active",joiningDate:"2023-04-12"},
  {id:"USR014",empId:"EMP014",name:"Sachin Shinde",email:"sachin.shinde@crm.com",password:"pass123",mobile:"9876543223",role:"Team Leader",groupId:"GRP001",teamId:"TM002",status:"Active",joiningDate:"2023-04-15"},
  {id:"USR018",empId:"EMP018",name:"Dhruv Shah",email:"dhruv.shah@crm.com",password:"pass123",mobile:"9876543227",role:"Team Leader",groupId:"GRP002",teamId:"TM004",status:"Active",joiningDate:"2023-05-05"},
  {id:"USR028",empId:"EMP028",name:"Nitin Chauhan",email:"nitin.chauhan@crm.com",password:"pass123",mobile:"9876543237",role:"Team Leader",groupId:"GRP004",teamId:"TM009",status:"Active",joiningDate:"2023-07-01"},
  {id:"USR029",empId:"EMP029",name:"Sonia Arora",email:"sonia.arora@crm.com",password:"pass123",mobile:"9876543238",role:"Team Coordinator",groupId:"GRP004",teamId:"TM009",status:"Active",joiningDate:"2023-07-02"},
  {id:"USR032",empId:"EMP032",name:"Sunil Yadav",email:"coord@crm.com",password:"coord123",mobile:"9876543241",role:"Team Leader",groupId:"GRP004",teamId:"TM011",status:"Active",joiningDate:"2023-07-10"},
  {id:"USR033",empId:"EMP033",name:"Mamta Tiwari",email:"mamta.tiwari@crm.com",password:"pass123",mobile:"9876543242",role:"Team Coordinator",groupId:"GRP004",teamId:"TM011",status:"Active",joiningDate:"2023-07-11"},
  {id:"USR041",empId:"EMP041",name:"Geetha Subramanian",email:"emp@crm.com",password:"emp123",mobile:"9876543250",role:"Employee",groupId:"GRP001",teamId:"TM001",status:"Active",joiningDate:"2023-09-02"},
  {id:"USR042",empId:"EMP042",name:"Sandeep Tomar",email:"sandeep.tomar@crm.com",password:"pass123",mobile:"9876543251",role:"Employee",groupId:"GRP001",teamId:"TM001",status:"Active",joiningDate:"2023-09-05"},
  {id:"USR043",empId:"EMP043",name:"Preeti Dubey",email:"preeti.dubey@crm.com",password:"pass123",mobile:"9876543252",role:"Employee",groupId:"GRP001",teamId:"TM001",status:"Active",joiningDate:"2023-09-10"},
  {id:"USR044",empId:"EMP044",name:"Vivek Pandey",email:"vivek.pandey@crm.com",password:"pass123",mobile:"9876543253",role:"Employee",groupId:"GRP001",teamId:"TM002",status:"Active",joiningDate:"2023-09-15"},
  {id:"USR045",empId:"EMP045",name:"Ritu Srivastava",email:"ritu.srivastava@crm.com",password:"pass123",mobile:"9876543254",role:"Employee",groupId:"GRP002",teamId:"TM004",status:"Active",joiningDate:"2023-10-01"},
  {id:"USR047",empId:"EMP047",name:"Sheetal Rathore",email:"sheetal.rathore@crm.com",password:"pass123",mobile:"9876543256",role:"Employee",groupId:"GRP004",teamId:"TM009",status:"Active",joiningDate:"2023-10-10"},
  {id:"USR048",empId:"EMP048",name:"Tarun Malhotra",email:"tarun.malhotra@crm.com",password:"pass123",mobile:"9876543257",role:"Employee",groupId:"GRP004",teamId:"TM009",status:"Active",joiningDate:"2023-10-15"},
  {id:"USR050",empId:"EMP050",name:"Deepti Chatterjee",email:"manager@crm.com",password:"mgr123",mobile:"9876543259",role:"Manager",groupId:"GRP008",teamId:null,status:"Active",joiningDate:"2023-11-05"},
]

const RAW_GROUPS = [
  {id:"GRP001",name:"Maharashtra",managerId:"USR002"},{id:"GRP002",name:"Gujarat",managerId:"USR003"},
  {id:"GRP003",name:"Rajasthan",managerId:"USR004"},{id:"GRP004",name:"Delhi NCR",managerId:"USR005"},
  {id:"GRP005",name:"Karnataka",managerId:"USR006"},{id:"GRP008",name:"West Bengal",managerId:"USR050"},
]

const RAW_TEAMS = [
  {id:"TM001",name:"Mumbai Team",groupId:"GRP001",leaderId:"USR012",coordinatorId:"USR013"},
  {id:"TM002",name:"Pune Team",groupId:"GRP001",leaderId:"USR014"},
  {id:"TM004",name:"Ahmedabad Team",groupId:"GRP002",leaderId:"USR018"},
  {id:"TM009",name:"Delhi Team",groupId:"GRP004",leaderId:"USR028",coordinatorId:"USR029"},
  {id:"TM011",name:"Gurgaon Team",groupId:"GRP004",leaderId:"USR032",coordinatorId:"USR033"},
]

const RAW_LEADS = [
  {id:"LEAD001",clientName:"Sarah Jenkins",clientCompany:"Acme Corp",clientMobile:"9876500001",clientEmail:"sarah@acme.com",state:"Maharashtra",city:"Mumbai",product:"Digital Business Card (V-Card)",callStatus:"Called - Interested",clientResponse:"Very Interested",regarding:"Client Requirement",status:"Contacted",leadCategory:"Hot",rating:80,paymentStatus:"Pay Today",nextCallDate:"2026-06-16",nextCallTime:"10:00",meetingType:"Followup",meetingAgendaType:"Product Demo",meetingDate:"2026-06-16",meetingTime:"10:00",meetingInitiatedBy:"USR041",assignedTo:"USR041",groupId:"GRP001",teamId:"TM001",businessCategory:"IT Services",notes:"Very interested in digital cards for her team.",createdBy:"USR041",createdAt:"2026-06-10 09:00:00",updatedAt:"2026-06-11 10:00:00",communications:[{type:"Call",date:"2026-06-10 09:00",user:"USR041",notes:"Initial call. Client interested in V-Card."},{type:"Email",date:"2026-06-11 10:00",user:"USR041",notes:"Sent product brochure and pricing."}]},
  {id:"LEAD002",clientName:"Marcus Chen",clientCompany:"TechFlow Solutions",clientMobile:"9876500002",clientEmail:"marcus@techflow.com",state:"Gujarat",city:"Ahmedabad",product:"CRM / ERP / CMS / eCommerce Software",callStatus:"Called - Callback",clientResponse:"Considering",regarding:"Client Demo",status:"Demo Scheduled",leadCategory:"Warm",rating:65,paymentStatus:"Pay This Week",nextCallDate:"2026-06-17",nextCallTime:"14:00",meetingType:"Meeting",meetingAgendaType:"Product Demo",meetingDate:"2026-06-17",meetingTime:"14:00",meetingInitiatedBy:"USR042",assignedTo:"USR042",groupId:"GRP001",teamId:"TM001",businessCategory:"Manufacturing",notes:"Need to send demo link before the meeting.",createdBy:"USR042",createdAt:"2026-06-08 11:00:00",updatedAt:"2026-06-09 09:00:00",communications:[{type:"Call",date:"2026-06-08 11:00",user:"USR042",notes:"Scheduled product demo."},{type:"Email",date:"2026-06-09 09:00",user:"USR042",notes:"Sent demo invite with Google Meet link."}]},
  {id:"LEAD003",clientName:"Elena Rodriguez",clientCompany:"Global Systems",clientMobile:"9876500003",clientEmail:"elena@global.com",state:"Delhi",city:"New Delhi",product:"Custom Website & App",callStatus:"Called - Interested",clientResponse:"Interested",regarding:"Client Meeting",status:"Proposal Sent",leadCategory:"Warm",rating:70,paymentStatus:"Pay Next Week",nextCallDate:"2026-06-20",nextCallTime:"11:30",meetingType:"Meeting",meetingAgendaType:"Requirement Discussion",meetingDate:"2026-06-18",meetingTime:"11:30",meetingInitiatedBy:"USR012",assignedTo:"USR012",groupId:"GRP001",teamId:"TM001",businessCategory:"Healthcare",notes:"Proposal sent via email. Awaiting feedback.",createdBy:"USR012",createdAt:"2026-06-05 09:00:00",updatedAt:"2026-06-06 09:00:00",communications:[{type:"Meeting",date:"2026-06-05 15:00",user:"USR012",notes:"In-person meeting at client office."},{type:"Email",date:"2026-06-06 09:00",user:"USR012",notes:"Sent detailed proposal document."}]},
  {id:"LEAD004",clientName:"David Kim",clientCompany:"Nexus Tech",clientMobile:"9876500004",clientEmail:"david@nexus.com",state:"Karnataka",city:"Bangalore",product:"Digital Marketing",callStatus:"Called - Interested",clientResponse:"Very Interested",regarding:"Client Query",status:"Negotiation",leadCategory:"Hot",rating:85,paymentStatus:"Pay Today",nextCallDate:"2026-06-16",nextCallTime:"16:00",meetingType:"Followup",meetingAgendaType:"Pricing Discussion",meetingDate:"2026-06-16",meetingTime:"16:00",meetingInitiatedBy:"USR041",assignedTo:"USR041",groupId:"GRP001",teamId:"TM001",businessCategory:"IT Services",notes:"Negotiating SEO+Social package price.",createdBy:"USR041",createdAt:"2026-05-20 10:00:00",updatedAt:"2026-05-28 14:00:00",communications:[{type:"Call",date:"2026-05-20 10:00",user:"USR041",notes:"Initial inquiry about digital marketing."},{type:"Call",date:"2026-05-28 14:00",user:"USR041",notes:"Price negotiation call."}]},
  {id:"LEAD005",clientName:"Jessica Smith",clientCompany:"Alpha Retail",clientMobile:"9876500005",clientEmail:"jessica@alpha.com",state:"Maharashtra",city:"Pune",product:"WhatsApp Store",callStatus:"Called - Not Interested",clientResponse:"Not Interested",regarding:"Client Query",status:"Lost",leadCategory:"Cold",rating:20,paymentStatus:"Pay Lost",nextCallDate:"2026-06-10",nextCallTime:"10:00",meetingType:"Followup",meetingAgendaType:"Budget Review",meetingDate:"2026-06-05",meetingTime:"10:00",meetingInitiatedBy:"USR041",assignedTo:"USR041",groupId:"GRP001",teamId:"TM001",businessCategory:"Retail",notes:"Client went with competitor. Budget too low.",createdBy:"USR041",createdAt:"2026-05-10 09:00:00",updatedAt:"2026-05-12 10:00:00",communications:[{type:"Call",date:"2026-05-10 09:00",user:"USR041",notes:"Client not interested. Price concern."}]},
  {id:"LEAD006",clientName:"Priya Kapoor",clientCompany:"Bright Minds",clientMobile:"9876500006",clientEmail:"priya@bright.com",state:"Maharashtra",city:"Nagpur",product:"Digital Business Card (V-Card)",callStatus:"Called - Callback",clientResponse:"Need More Info",regarding:"Client Requirement",status:"Follow-up Scheduled",leadCategory:"Warm",rating:55,paymentStatus:"Pay This Week",nextCallDate:"2026-06-17",nextCallTime:"15:30",meetingType:"Followup",meetingAgendaType:"Feature Discussion",meetingDate:"2026-06-17",meetingTime:"15:30",meetingInitiatedBy:"USR043",assignedTo:"USR043",groupId:"GRP001",teamId:"TM001",businessCategory:"Education",notes:"Asked for more details on V-Card features.",createdBy:"USR043",createdAt:"2026-06-12 11:00:00",updatedAt:"2026-06-12 11:00:00",communications:[{type:"Call",date:"2026-06-12 11:00",user:"USR043",notes:"Initial call. Client wants brochure."}]},
  {id:"LEAD007",clientName:"Rahul Sharma",clientCompany:"Metro Developers",clientMobile:"9876500007",clientEmail:"rahul@metro.com",state:"Gujarat",city:"Surat",product:"Custom Website & App",callStatus:"Called - Interested",clientResponse:"Very Interested",regarding:"Client Demo",status:"Close (Won)",leadCategory:"Hot",rating:95,paymentStatus:"Pay Today",nextCallDate:"2026-06-20",nextCallTime:"10:00",meetingType:"Meeting",meetingAgendaType:"Contract Signing",meetingDate:"2026-06-13",meetingTime:"10:00",meetingInitiatedBy:"USR018",assignedTo:"USR018",groupId:"GRP002",teamId:"TM004",businessCategory:"Real Estate",notes:"Deal closed. Payment received.",createdBy:"USR018",createdAt:"2026-05-01 10:00:00",updatedAt:"2026-05-20 09:00:00",communications:[{type:"Call",date:"2026-05-01 10:00",user:"USR018",notes:"Initial call."},{type:"Meeting",date:"2026-05-15 14:00",user:"USR018",notes:"Demo meeting — client loved the product."},{type:"Email",date:"2026-05-20 09:00",user:"USR018",notes:"Sent invoice. Deal won!"}]},
  {id:"LEAD008",clientName:"Anjali Mehta",clientCompany:"Star Exports",clientMobile:"9876500008",clientEmail:"anjali@star.com",state:"Delhi",city:"Gurgaon",product:"CRM / ERP / CMS / eCommerce Software",callStatus:"Not Called",clientResponse:"",regarding:"Client Meeting",status:"New Lead",leadCategory:"Warm",rating:45,paymentStatus:"Pay Next Week",nextCallDate:"2026-06-19",nextCallTime:"09:00",meetingType:"Meeting",meetingAgendaType:"Initial Discussion",meetingDate:"2026-06-19",meetingTime:"09:00",meetingInitiatedBy:"USR028",assignedTo:"USR028",groupId:"GRP004",teamId:"TM009",businessCategory:"Logistics",notes:"New prospect from reference.",createdBy:"USR028",createdAt:"2026-06-15 09:00:00",updatedAt:"2026-06-15 09:00:00",communications:[]},
  {id:"LEAD009",clientName:"Vikram Gupta",clientCompany:"Nova Industries",clientMobile:"9876500009",clientEmail:"vikram@nova.com",state:"Rajasthan",city:"Jaipur",product:"Digital Marketing",callStatus:"Called - Not Reachable",clientResponse:"Need More Info",regarding:"Others",status:"New Lead",leadCategory:"Solo",rating:40,paymentStatus:"Pay Ignoring",nextCallDate:"2026-06-16",nextCallTime:"11:00",meetingType:"Followup",meetingAgendaType:"Callback",meetingDate:"2026-06-14",meetingTime:"11:00",meetingInitiatedBy:"USR041",assignedTo:"USR041",groupId:"GRP001",teamId:"TM001",businessCategory:"Manufacturing",notes:"Follow-up call needed.",createdBy:"USR041",createdAt:"2026-06-14 09:00:00",updatedAt:"2026-06-14 09:00:00",communications:[]},
  {id:"LEAD010",clientName:"Sneha Reddy",clientCompany:"Pioneer Software",clientMobile:"9876500010",clientEmail:"sneha@pioneer.com",state:"Karnataka",city:"Mysore",product:"WhatsApp Store",callStatus:"Called - Busy",clientResponse:"Interested",regarding:"Client Query",status:"Contacted",leadCategory:"Warm",rating:60,paymentStatus:"Pay Tomorrow",nextCallDate:"2026-06-17",nextCallTime:"13:00",meetingType:"Followup",meetingAgendaType:"Product Walkthrough",meetingDate:"2026-06-17",meetingTime:"13:00",meetingInitiatedBy:"USR041",assignedTo:"USR041",groupId:"GRP001",teamId:"TM001",businessCategory:"IT Services",notes:"Interested in WA store for retail ops.",createdBy:"USR041",createdAt:"2026-06-13 10:00:00",updatedAt:"2026-06-13 10:00:00",communications:[{type:"Call",date:"2026-06-13 10:00",user:"USR041",notes:"Client answered briefly. Will call back."}]},
  {id:"LEAD011",clientName:"Aditya Rao",clientCompany:"Pacific Traders",clientMobile:"9876500011",clientEmail:"aditya@pacific.com",state:"Gujarat",city:"Vadodara",product:"Other Services",callStatus:"Called - Interested",clientResponse:"Considering",regarding:"Client Requirement",status:"Follow-up Scheduled",leadCategory:"Warm",rating:50,paymentStatus:"Pay This Week",nextCallDate:"2026-06-20",nextCallTime:"10:00",meetingType:"Followup",meetingAgendaType:"Custom Requirements",meetingDate:"2026-06-11",meetingTime:"10:00",meetingInitiatedBy:"USR045",assignedTo:"USR045",groupId:"GRP002",teamId:"TM004",businessCategory:"Consulting",notes:"Needs custom solution discussion.",createdBy:"USR045",createdAt:"2026-06-11 09:00:00",updatedAt:"2026-06-11 09:00:00",communications:[{type:"Call",date:"2026-06-11 09:00",user:"USR045",notes:"Discussed requirements. Follow-up next week."}]},
  {id:"LEAD012",clientName:"Meera Joshi",clientCompany:"Sunrise Hotels",clientMobile:"9876500012",clientEmail:"meera@sunrise.com",state:"Delhi",city:"New Delhi",product:"Digital Marketing",callStatus:"Called - Callback",clientResponse:"Very Interested",regarding:"Client Demo",status:"Proposal Sent",leadCategory:"Hot",rating:75,paymentStatus:"Pay Tomorrow",nextCallDate:"2026-06-18",nextCallTime:"15:00",meetingType:"Meeting",meetingAgendaType:"Social Media Proposal",meetingDate:"2026-06-16",meetingTime:"15:00",meetingInitiatedBy:"USR047",assignedTo:"USR047",groupId:"GRP004",teamId:"TM009",businessCategory:"Hospitality",notes:"Hotel chain wants social media management.",createdBy:"USR047",createdAt:"2026-06-09 11:00:00",updatedAt:"2026-06-10 09:00:00",communications:[{type:"Call",date:"2026-06-09 11:00",user:"USR047",notes:"Client very interested."},{type:"Email",date:"2026-06-10 09:00",user:"USR047",notes:"Sent proposal for 6-month package."}]},
  {id:"LEAD013",clientName:"Ramesh Patil",clientCompany:"FreshFarm Exports",clientMobile:"9876500013",clientEmail:"ramesh@freshfarm.com",state:"Maharashtra",city:"Nashik",product:"Custom Website & App",callStatus:"Called - Interested",clientResponse:"Very Interested",regarding:"Client Demo",status:"Hot",leadCategory:"Hot",rating:88,paymentStatus:"Pay Today",nextCallDate:"2026-06-16",nextCallTime:"12:00",meetingType:"Meeting",meetingAgendaType:"Live Demo",meetingDate:"2026-06-16",meetingTime:"12:00",meetingInitiatedBy:"USR012",assignedTo:"USR012",groupId:"GRP001",teamId:"TM001",businessCategory:"Manufacturing",notes:"Urgent requirement. Budget approved.",createdBy:"USR012",createdAt:"2026-06-14 08:00:00",updatedAt:"2026-06-14 08:00:00",communications:[{type:"Call",date:"2026-06-14 08:00",user:"USR012",notes:"Client confirmed budget and timeline."}]},
  {id:"LEAD014",clientName:"Kavita Nair",clientCompany:"BrightKids Academy",clientMobile:"9876500014",clientEmail:"kavita@brightkids.com",state:"Kerala",city:"Kochi",product:"Digital Business Card (V-Card)",callStatus:"Called - Callback",clientResponse:"Considering",regarding:"Client Requirement",status:"Warm",leadCategory:"Warm",rating:52,paymentStatus:"Pay This Week",nextCallDate:"2026-06-18",nextCallTime:"11:00",meetingType:"Followup",meetingAgendaType:"Use Case Review",meetingDate:"2026-06-12",meetingTime:"11:00",meetingInitiatedBy:"USR043",assignedTo:"USR043",groupId:"GRP001",teamId:"TM001",businessCategory:"Education",notes:"School interested in teacher V-Cards.",createdBy:"USR043",createdAt:"2026-06-10 11:00:00",updatedAt:"2026-06-10 11:00:00",communications:[{type:"Call",date:"2026-06-10 11:00",user:"USR043",notes:"Sent brochure. Will decide this week."}]},
]

export const Data = {
  _init() {
    if (!localStorage.getItem('crm_users')) localStorage.setItem('crm_users', JSON.stringify(RAW_USERS))
    if (!localStorage.getItem('crm_leads')) localStorage.setItem('crm_leads', JSON.stringify(RAW_LEADS))
    if (!localStorage.getItem('crm_groups')) localStorage.setItem('crm_groups', JSON.stringify(RAW_GROUPS))
    if (!localStorage.getItem('crm_teams')) localStorage.setItem('crm_teams', JSON.stringify(RAW_TEAMS))
  },

  loadAll() {
    this._init()
    return Promise.resolve()
  },

  getAll(k) {
    return JSON.parse(localStorage.getItem('crm_' + k) || '[]')
  },

  save(k, v) {
    localStorage.setItem('crm_' + k, JSON.stringify(v))
  },

  getById(k, id) {
    return this.getAll(k).find(x => x.id === id) || null
  },

  upsert(k, item) {
    const all = this.getAll(k)
    const i = all.findIndex(x => x.id === item.id)
    if (i >= 0) all[i] = item
    else all.unshift(item)
    this.save(k, all)
    return item
  },

  remove(k, id) {
    this.save(k, this.getAll(k).filter(x => x.id !== id))
  },

  getLeadsForUser(user) {
    const leads = this.getAll('leads')
    if (!user) return leads
    if (user.role === 'Admin') return leads
    if (user.role === 'Manager') return leads.filter(l => l.groupId === user.groupId)
    if (user.role === 'Team Leader' || user.role === 'Team Coordinator') {
      const members = this.getAll('users').filter(u => u.teamId === user.teamId).map(u => u.id)
      return leads.filter(l => members.includes(l.assignedTo) || l.assignedTo === user.userId)
    }
    return leads.filter(l => l.assignedTo === user.userId)
  },

  getUsersForUser(user) {
    const users = this.getAll('users')
    if (user.role === 'Admin') return users
    if (user.role === 'Manager') return users.filter(u => u.groupId === user.groupId)
    return users.filter(u => u.teamId === user.teamId)
  },

  getEmployeesForUser(user) {
    return this.getUsersForUser(user).filter(u => u.status === 'Active')
  },

  getUserName(id) {
    const u = this.getById('users', id)
    return u ? u.name : (id || '—')
  },

  getGroupName(id) {
    const g = this.getById('groups', id)
    return g ? g.name : (id || '—')
  },

  getTeamName(id) {
    const t = this.getById('teams', id)
    return t ? t.name : (id || '—')
  },

  nextLeadId() {
    const n = Math.max(0, ...this.getAll('leads').map(l => parseInt(l.id.replace('LEAD', '')) || 0))
    return 'LEAD' + String(n + 1).padStart(3, '0')
  },

  nextUserId() {
    const n = Math.max(0, ...this.getAll('users').map(u => parseInt(u.id.replace('USR', '')) || 0))
    return 'USR' + String(n + 1).padStart(3, '0')
  }
}
