import { Data } from './data'

export const Auth = {
  KEY: 'crm_session',
  
  login(email, password) {
    const users = Data.getAll('users')
    const user = users.find(u => u.email === email && u.password === password)
    if (!user) return { ok: false, msg: 'Invalid email or password.' }
    if (user.status !== 'Active') return { ok: false, msg: 'Account deactivated. Contact admin.' }
    const s = {
      userId: user.id,
      role: user.role,
      name: user.name,
      email: user.email,
      groupId: user.groupId,
      teamId: user.teamId
    }
    sessionStorage.setItem(this.KEY, JSON.stringify(s))
    return { ok: true, user: s }
  },
  
  logout() {
    sessionStorage.removeItem(this.KEY)
  },
  
  me() {
    const s = sessionStorage.getItem(this.KEY)
    return s ? JSON.parse(s) : null
  },
  
  can(action, role) {
    const p = {
      delete_lead: ['Admin', 'Manager'],
      assign_lead: ['Admin', 'Manager', 'Team Leader', 'Team Coordinator'],
      create_user: ['Admin'],
      delete_user: ['Admin'],
      edit_user: ['Admin'],
      view_reports: ['Admin', 'Manager', 'Team Leader'],
      manage_users: ['Admin']
    }
    return (p[action] || []).includes(role || '')
  }
}
